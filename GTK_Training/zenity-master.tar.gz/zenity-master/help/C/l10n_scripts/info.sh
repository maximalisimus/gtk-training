#!/bin/bash

                  zenity --info \
                  --text="Merge complete. Updated 3 of 10 files."
